const PASS = '1601';
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const photos = [
"assets/photos/1000038366.jpg","assets/photos/1000038370.jpg","assets/photos/1000038371.jpg","assets/photos/1000038372.jpg","assets/photos/1000038373.jpg","assets/photos/1000039420.jpg","assets/photos/1000039562.jpg","assets/photos/1000039563.jpg","assets/photos/1000039636.png","assets/photos/1000039637.jpg","assets/photos/1000039638.jpg","assets/photos/1000039639.jpg","assets/photos/1000039640.jpg","assets/photos/1000039641.jpg","assets/photos/1000039642.jpg","assets/photos/1000039643.jpg","assets/photos/1000039644.jpg","assets/photos/1000039645.jpg","assets/photos/1000039646.jpg","assets/photos/1000039647.jpg","assets/photos/1000039648.jpg","assets/photos/1000039649.jpg","assets/photos/1000039650.jpg","assets/photos/1000039651.jpg","assets/photos/1000039969.jpg","assets/photos/1000039970.jpg","assets/photos/1000039971.jpg","assets/photos/1000039972.jpg","assets/photos/1000040401.jpg","assets/photos/1000040402.jpg","assets/photos/1000040403.jpg","assets/photos/1000040404.jpg","assets/photos/1000040405.jpg","assets/photos/1000040406.jpg","assets/photos/1000040408.jpg","assets/photos/1000040409.jpg","assets/photos/1000040412.jpg","assets/photos/1000040413.jpg","assets/photos/1000040414.jpg","assets/photos/1000040415.jpg","assets/photos/1000040417.jpg","assets/photos/1000040494.jpg","assets/photos/1000040773.jpg","assets/photos/1000040774.jpg","assets/photos/1000040775.jpg","assets/photos/1000040776.jpg","assets/photos/1000040777.jpg","assets/photos/1000040778.jpg","assets/photos/1000040779.jpg","assets/photos/1000040780.jpg","assets/photos/1000040843.jpg","assets/photos/1000040844.jpg","assets/photos/1000040845.jpg","assets/photos/1000040846.jpg","assets/photos/1000040847.jpg","assets/photos/1000040848.jpg","assets/photos/1000040849.jpg","assets/photos/1000040850.jpg","assets/photos/1000040909.jpg"];
const videos = ["assets/videos/1000038364.mp4","assets/videos/1000038365.mp4","assets/videos/1000039566.mp4","assets/videos/1000039568.mp4","assets/videos/1000039569.mp4","assets/videos/1000039570.mp4","assets/videos/1000040035.mp4","assets/videos/1000040400.mp4","assets/videos/1000040416.mp4","assets/videos/1000040784.mp4","assets/videos/1000040785.mp4","assets/videos/1000040792.mp4","assets/videos/1000040800.mp4","assets/videos/1000040801.mp4","assets/videos/1000040802.mp4","assets/videos/1000040803.mp4","assets/videos/1000040804.mp4","assets/videos/1000040805.mp4"];

let entered = '';
let currentPhoto = 0;
let audioContext;

function makeStars(target, count=110){
  target.innerHTML='';
  for(let i=0;i<count;i++){
    const s=document.createElement('i'); s.className='star';
    s.style.left=Math.random()*100+'%'; s.style.top=Math.random()*100+'%';
    s.style.setProperty('--d',(2+Math.random()*4)+'s'); s.style.setProperty('--delay',(-Math.random()*5)+'s');
    target.appendChild(s);
  }
}
makeStars($('#stars'));

function updateDots(){ $$('#dots i').forEach((d,i)=>d.classList.toggle('filled',i<entered.length)); }
function resetCode(){ entered=''; updateDots(); }
function unlock(){
  $('#lock').classList.add('unlocking');
  burst('unlock');
  setTimeout(()=>{
    $('#lock').classList.add('hidden'); $('#app').classList.remove('hidden');
    document.body.classList.add('is-open');
    window.scrollTo(0,0);
  },900);
}
function check(){
  if(entered===PASS){ unlock(); }
  else { $('#wrong').textContent='Not quite… try again, pretty girl. ♡'; $('#keypad').classList.add('shake'); setTimeout(()=>$('#keypad').classList.remove('shake'),450); resetCode(); }
}
$('#enterBtn').onclick=()=>{ $('#keypad').classList.remove('hidden'); $('#enterBtn').classList.add('hidden'); $('#keypad').animate([{opacity:0,transform:'translateY(15px)'},{opacity:1,transform:'translateY(0)'}],{duration:500,fill:'forwards'}); };
$$('.keys button').forEach(b=>b.onclick=()=>{
  const k=b.dataset.k;
  if(k==='clear') entered=entered.slice(0,-1);
  else if(k==='enter') return check();
  else if(entered.length<4) entered+=k;
  updateDots();
  if(entered.length===4) setTimeout(check,120);
});

function burst(type='soft'){
  const layer=$('#particles');
  if(!layer) return;
  const count=type==='unlock'?70:22;
  for(let i=0;i<count;i++){
    const p=document.createElement('span'); p.className='burst-particle';
    p.textContent=Math.random()>.55?'✦':'♡';
    p.style.left='50%'; p.style.top='50%';
    p.style.setProperty('--x',(Math.random()*2-1)*window.innerWidth*.55+'px');
    p.style.setProperty('--y',(Math.random()*2-1)*window.innerHeight*.45+'px');
    p.style.setProperty('--r',(Math.random()*720-360)+'deg');
    layer.appendChild(p); setTimeout(()=>p.remove(),1400);
  }
}

const views={
 moments(){return {title:'Our Moments',sub:'59 little pieces of a beautiful story.',body:`<div class="memory-intro">Tap a photo. Stay for a second. Let the memory breathe.</div><div class="photo-grid">${photos.map((p,i)=>`<button class="photo-tile" data-photo="${i}"><img src="${p}" alt="Memory ${i+1}" loading="lazy"><span>${String(i+1).padStart(2,'0')}</span></button>`).join('')}</div>`}},
 movies(){return {title:'Little Movies',sub:'Press play when you miss us.',body:`<div class="video-grid">${videos.map((p,i)=>`<article class="video-card"><video src="${p}" controls preload="metadata" playsinline></video><span>little movie ${String(i+1).padStart(2,'0')}</span></article>`).join('')}</div>`}},
 letters(){return {title:'Letters For You',sub:'Open one slowly. Some things deserve time.',body:`<div class="envelope-stack"><button class="envelope" data-letter="smile"><span>♡</span><b>Open when you need a smile</b><small>tap to unfold</small></button><button class="envelope" data-letter="miss"><span>✦</span><b>Open when you miss me</b><small>tap to unfold</small></button><button class="envelope" data-letter="future"><span>∞</span><b>Open when you wonder what's next</b><small>tap to unfold</small></button></div><div id="letterPaper" class="letter-paper hidden"></div>`}},
 love(){const x=['Your smile when you forget anyone is watching.','The little things that make you genuinely excited.','How a normal day becomes a memory when you are in it.','The softness you bring into a room.','The person you are when nobody is asking you to perform.','The way you make me want to notice the little things.','The fact that somehow, out of everyone, you are you.','Basically… you.'];return {title:'Things I Love About You',sub:'An unfinished list. I think it will stay unfinished forever.',body:`<div class="love-list">${x.map((t,i)=>`<article class="love-card"><span>#${String(i+1).padStart(2,'0')}</span><p>${t}</p></article>`).join('')}</div>`}},
 soundtrack(){const tracks=[['Haareya — cover','for the feeling of finding someone who stays in your thoughts'],['Tu Chahiye','for the moments when one person is enough'],['Something About You','for the dreamy, impossible-to-explain parts'],['Ruposh','for the nights that deserve a little cinema'],['Mere Nishan','for memories that leave a mark'],['I Like Me Better','for the lightness of being around you'],['Until I Found You','for the old-soul kind of romance'],['Heeriye','for the soft, sunny days'],['Apna Bana Le','for the feeling of home'],['Iktara','for the quiet, wandering moments']];return {title:'Our Soundtrack',sub:'Songs that now sound a little more like you.',body:`<div class="track-list">${tracks.map((t,i)=>`<button class="track" data-track="${i}"><span class="vinyl"><i></i></span><span><b>${t[0]}</b><small>${t[1]}</small></span><em>♡</em></button>`).join('')}</div><div class="lyric-note"><span>✦</span><p>Short song moments can live between memories. For full lyrics, use lyrics you own or provide; this app keeps the soundtrack elegant and original.</p></div>`}},
 surprises(){return {title:'Tiny Surprises',sub:'The best things are usually hidden.',body:`<div class="surprise-grid"><button data-secret="1">🎀<b>A ribbon</b><small>untie it</small></button><button data-secret="2">🌙<b>The moon</b><small>look closer</small></button><button data-secret="3">📦<b>A tiny box</b><small>open me</small></button><button data-secret="4">🌹<b>A rose</b><small>for no reason</small></button></div><div id="secretResult" class="secret-result"></div>`}},
 room(){return {title:"Kenisha's Room",sub:'A tiny room where everything has a meaning.',body:`<div class="room"><button class="object window" data-room="window">☾<small>look outside</small></button><button class="object lamp" data-room="lamp">⌁<small>soft light</small></button><button class="object teddy" data-room="teddy">🧸<small>hello</small></button><button class="object diary" data-room="diary">📖<small>diary</small></button><button class="object musicbox" data-room="music">♫<small>our song</small></button></div><div id="roomMessage" class="room-message">Tap something.</div>`}}
};

function openView(name){
  const v=views[name]();
  $('#modalBody').innerHTML=`<div class="modal-head"><div><p class="eyebrow">${name==='moments'?'A MEMORY COLLECTION':'A LITTLE CORNER'}</p><h2 class="modal-title">${v.title}</h2><p class="modal-sub">${v.sub}</p></div><button id="close" class="close">×</button></div>${v.body}`;
  $('#modal').classList.remove('hidden'); document.body.classList.add('modal-open');
  $('#close').onclick=closeModal;
  bindViewEvents(name);
}
function closeModal(){ $('#modal').classList.add('hidden'); document.body.classList.remove('modal-open'); }
function bindViewEvents(name){
  if(name==='moments') $$('.photo-tile').forEach(b=>b.onclick=()=>showPhoto(+b.dataset.photo));
  if(name==='letters') $$('.envelope').forEach(b=>b.onclick=()=>openLetter(b.dataset.letter));
  if(name==='soundtrack') $$('.track').forEach(b=>b.onclick=()=>{burst(); toast('Saved to your little soundtrack ♡');});
  if(name==='surprises') $$('.surprise-grid button').forEach(b=>b.onclick=()=>showSecret(b.dataset.secret));
  if(name==='room') $$('.object').forEach(b=>b.onclick=()=>roomAction(b.dataset.room));
}
function showPhoto(i){currentPhoto=i; renderPhoto(); $('#photoViewer').classList.remove('hidden');}
function renderPhoto(){ $('#photoViewer img').src=photos[currentPhoto]; $('#photoCount').textContent=`${String(currentPhoto+1).padStart(2,'0')} / ${photos.length}`; }
$('#prevPhoto').onclick=()=>{currentPhoto=(currentPhoto-1+photos.length)%photos.length;renderPhoto()};
$('#nextPhoto').onclick=()=>{currentPhoto=(currentPhoto+1)%photos.length;renderPhoto()};
$('#closePhoto').onclick=()=>$('#photoViewer').classList.add('hidden');
function openLetter(kind){const texts={smile:['Open when you need a smile','There is something about you that makes ordinary moments stay. If today feels heavy, come back here and remember: somewhere in this little world, there is a version of you being celebrated simply for being you.'],miss:['Open when you miss me','If I could fold a feeling into an envelope, I would send you the feeling of being close. Until then, keep this little place. It is a tiny reminder that distance never gets the final word.'],future:["Open when you wonder what's next",'I do not know every chapter ahead. I only know that the idea of more memories with you feels like a beautiful thing to look forward to.']};const t=texts[kind];const p=$('#letterPaper');p.innerHTML=`<span>♡</span><h3>${t[0]}</h3><p>${t[1]}</p><small>with love, always</small>`;p.classList.remove('hidden');p.scrollIntoView({behavior:'smooth',block:'center'});}
function showSecret(n){const msgs={1:'You found the ribbon. It says: “Some things are prettier when you take your time with them.”',2:'You found the moon. Come back after dark — this little universe changes with you.',3:'Inside the tiny box: one imaginary ticket to anywhere, as long as you are there.',4:'The rose is for no special occasion. That is the whole point.'};$('#secretResult').textContent=msgs[n];burst();}
function roomAction(n){const m={window:'The sky outside is quiet tonight. I hope you always have somewhere peaceful to look.',lamp:'Soft light on. Some memories deserve warm lighting.',teddy:'The teddy says: you are officially allowed one unnecessary smile.',diary:'The diary is mostly full of things I was too shy to say out loud.',music:'♫ This is where your soundtrack lives. Pick a song and stay a while.'};$('#roomMessage').textContent=m[n];burst('soft');}
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),1800)}

$$('[data-view]').forEach(b=>b.onclick=()=>openView(b.dataset.view));
$('#close').onclick=closeModal; $('#modal').onclick=e=>{if(e.target===e.currentTarget)closeModal()};
$('#musicBtn').onclick=()=>toast('Your soundtrack is ready for the songs you choose ♫');
$('#secretLogo').onclick=()=>{burst();toast('You found the hidden star ✦')};

document.addEventListener('keydown',e=>{if($('#lock').classList.contains('hidden')){if(e.key==='Escape'){closeModal();$('#photoViewer').classList.add('hidden')}}});
let touchStartX=0;$('#photoViewer').addEventListener('touchstart',e=>touchStartX=e.changedTouches[0].screenX,{passive:true});$('#photoViewer').addEventListener('touchend',e=>{const dx=e.changedTouches[0].screenX-touchStartX;if(Math.abs(dx)>50){if(dx<0)$('#nextPhoto').click();else $('#prevPhoto').click()}},{passive:true});
