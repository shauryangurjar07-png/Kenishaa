KENISHA — A Little World

A polished offline-first romantic PWA built around the supplied photos and videos.

Passcode: 1601
Photos included: 59
Videos included: 18

Open index.html in a modern browser or serve this folder from a local/static web server for full PWA behavior.

Notes:
- Song names are used as soundtrack labels; no copyrighted audio is bundled.
- The app uses short references and original romantic notes rather than reproducing full copyrighted lyrics.
- All supplied media is kept locally under assets/photos and assets/videos.
