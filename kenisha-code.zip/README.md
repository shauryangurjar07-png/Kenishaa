# Kenisha Android App

This is a self-contained Android WebView project containing the Kenisha offline web app and bundled media.

## Online build
Upload the **contents of this ZIP as the project root** to an Android project builder. Select **APK** and **debug/development** build if offered.

The project uses Android Gradle Plugin 8.5.2, Gradle 8.7, Java 17, and compile/target SDK 34 for broad online-builder compatibility.

No external app assets are required; the website, photos, videos, styles and scripts are under `app/src/main/assets/`.
